from django.shortcuts import render
from django.shortcuts import render
from .models import *
from django.contrib import messages
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.models import User, auth
# Create your views here.


def home(request):
    return render(request,'home.html')


def Register(request):
    if request.method == 'POST':
        name = request.POST.get('f_name')
        number = request.POST.get('l_name')
        rg = Registration()
        rg.Name = name
        rg.number = number
        rg.save()
        messages.success(request, 'You have successfully registered')
        return redirect('home')
    else:
        return render(request, 'register.html')

def edit(request, id):
    rg = Registration.objects.get(id=id)
    if request.method == 'POST':
        f_name = request.POST.get('f_name')
        l_name = request.POST.get('l_name')
        rg1 = Registration.objects.get(id=id)
        rg1.Name = f_name
        rg1.number = l_name
        rg1.save()
        messages.success(request, 'Updated successfully')
        return redirect('view')
    else:
        return render(request, 'edit.html',{'rg': rg})

def view(request):
    ac = Registration.objects.all()
    return render(request, "view.html", {'ac': ac})

def delete(request ,id):
    Registration.objects.get(id=id).delete()
    messages.success(request, 'Deleted ')
    return redirect('view')
