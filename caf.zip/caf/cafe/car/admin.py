from django.contrib import admin
from . models import *
admin.site.register(Registration)

# Register your models here.
