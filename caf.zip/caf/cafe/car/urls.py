from django.urls import path
import car.views
urlpatterns = [
    path('',car.views.home,name = 'home'),
    path('edit/<id>',car.views.edit,name = 'edit'),
    path('Register',car.views.Register,name = 'Register'),
    path('delete/<id>',car.views.delete,name = 'delete'),
    path('view',car.views.view,name = 'view'),
]